CREATE DATABASE IF NOT EXISTS `database_trider`;

USE database_trider;

DROP TABLE IF EXISTS `bookings`;

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(255) NOT NULL,
  `origin_point` varchar(255) NOT NULL,
  `destination_point` varchar(255) NOT NULL,
  `client_phone` tinytext NOT NULL,
  `driver_name` varchar(255) NOT NULL,
  `driver_phone` tinytext NOT NULL,
  `fare` int(32) NOT NULL,
  `toda` tinytext NOT NULL,
  `date_booked` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;




DROP TABLE IF EXISTS `client_list`;

CREATE TABLE `client_list` (
  `user_id` int(11) NOT NULL,
  `client_firstname` varchar(255) NOT NULL,
  `client_middlename` varchar(255) NOT NULL,
  `client_lastname` varchar(255) NOT NULL,
  `client_suffix` varchar(11) NOT NULL,
  `gender` tinytext NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `client_list` VALUES("4","Asdasd","Asdas","Asda","jrszk","Male");
INSERT INTO `client_list` VALUES("8","Client","One","Juan","jr","Male");



DROP TABLE IF EXISTS `driver_list`;

CREATE TABLE `driver_list` (
  `user_id` int(255) NOT NULL,
  `driver_firstname` varchar(255) NOT NULL,
  `driver_middlename` varchar(255) NOT NULL,
  `driver_lastname` varchar(255) NOT NULL,
  `driver_sufix` varchar(11) NOT NULL,
  `gender` tinytext NOT NULL,
  `plate_number` varchar(255) NOT NULL,
  `license` varchar(255) NOT NULL,
  `toda` tinytext NOT NULL,
  `mtop` tinytext NOT NULL,
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `driver_list` VALUES("11","Mark Jayson","Qwerty","Algarne","jr","Male","89564651312","89465435","SATODA","3001");
INSERT INTO `driver_list` VALUES("17","Mark Jayson","One","Algarne","jr","Male","5656464","549561","satoda","3005");



DROP TABLE IF EXISTS `user_list`;

CREATE TABLE `user_list` (
  `user_id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `position` tinytext NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_list` VALUES("2","admin","$2y$10$r4O/4/VnlqIdJ8l6v80FE.nNu0Un8xf39dR/sXfSk9FGFkWnz8tZq","09123456789","admin@example.com","Administrator");
INSERT INTO `user_list` VALUES("8","client1","$2y$10$Ss6UsDvdPg/aQEBz2zXAa.XvgA3.e5t21MfLLyVwqUn8QDZ2Zgs6m","09125321455","client1@example.com","User");
INSERT INTO `user_list` VALUES("11","satoda","$2y$10$kJNjKClcoNHURBARdMxaRefs0H0ZG/oKdQedmLZ8xkQBkFEJeDzg6","09998989898","MarkJayson@example.com","Co-Admin");
INSERT INTO `user_list` VALUES("17","mj1122","$2y$10$Sx0Wi5Ak0D/uKSgaqref6ehxuY.4El4KJzPzQkNhAsyxZDhlMS4hu","09125345551","MarkJayson848484@example.com","Driver");



DROP TABLE IF EXISTS `user_log`;

CREATE TABLE `user_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` tinytext NOT NULL,
  `action` varchar(255) NOT NULL,
  `logDate` date NOT NULL,
  `logTime` time NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_log` VALUES("1","4","dasdas","Register","2022-12-15","12:07:14");
INSERT INTO `user_log` VALUES("2","2","admin","Login","2022-12-15","12:22:53");
INSERT INTO `user_log` VALUES("3","2","admin","Login","2022-12-15","12:23:02");
INSERT INTO `user_log` VALUES("4","2","admin","Logout","2022-12-15","12:26:16");
INSERT INTO `user_log` VALUES("5","2","admin","Login","2022-12-15","12:26:19");
INSERT INTO `user_log` VALUES("6","2","admin","Logout","2022-12-15","12:27:24");
INSERT INTO `user_log` VALUES("7","2","admin","Login","2022-12-15","12:27:27");
INSERT INTO `user_log` VALUES("8","2","admin","Logout","2022-12-15","12:30:41");
INSERT INTO `user_log` VALUES("9","2","admin","Login","2022-12-15","12:30:43");
INSERT INTO `user_log` VALUES("10","2","admin","Logout","2022-12-15","12:31:24");
INSERT INTO `user_log` VALUES("11","2","admin","Login","2022-12-15","12:31:26");
INSERT INTO `user_log` VALUES("12","2","admin","Logout","2022-12-15","12:37:46");
INSERT INTO `user_log` VALUES("13","2","admin","Login","2022-12-15","12:37:48");
INSERT INTO `user_log` VALUES("14","2","admin","Logout","2022-12-15","12:38:40");
INSERT INTO `user_log` VALUES("15","2","admin","Login","2022-12-15","12:39:54");
INSERT INTO `user_log` VALUES("16","2","admin","Login","2022-12-15","12:42:07");
INSERT INTO `user_log` VALUES("17","2","admin","Logout","2022-12-15","01:44:41");
INSERT INTO `user_log` VALUES("18","2","admin","Login","2022-12-15","01:45:02");
INSERT INTO `user_log` VALUES("19","5","dsaaa","Register","2022-12-15","03:49:55");
INSERT INTO `user_log` VALUES("20","6","dsaaaasd","Registered Asdas Asdas Asd to client list","2022-12-15","04:02:09");
INSERT INTO `user_log` VALUES("21","7","asd","Registered Asd Asdas Asdasd to client list","2022-12-15","04:05:30");
INSERT INTO `user_log` VALUES("22","2","admin","Login","2022-12-19","04:53:14");
INSERT INTO `user_log` VALUES("23","2","admin","Login","2022-12-19","05:36:52");
INSERT INTO `user_log` VALUES("24","2","admin","Logout","2022-12-19","05:36:57");
INSERT INTO `user_log` VALUES("25","2","admin","Login","2022-12-19","05:37:01");
INSERT INTO `user_log` VALUES("26","2","admin","Logout","2022-12-19","05:51:40");
INSERT INTO `user_log` VALUES("27","2","admin","Login","2022-12-19","05:51:43");
INSERT INTO `user_log` VALUES("28","2","admin","Logout","2022-12-19","06:01:58");
INSERT INTO `user_log` VALUES("29","8","client1","Register","2022-12-19","06:04:53");
INSERT INTO `user_log` VALUES("30","8","client1","Login","2022-12-19","06:05:03");
INSERT INTO `user_log` VALUES("31","8","client1","Login","2022-12-19","06:07:48");
INSERT INTO `user_log` VALUES("32","8","client1","Login","2022-12-19","06:08:23");
INSERT INTO `user_log` VALUES("33","8","client1","Logout","2022-12-19","06:14:09");
INSERT INTO `user_log` VALUES("34","2","admin","Login","2022-12-19","06:14:15");
INSERT INTO `user_log` VALUES("35","2","admin","Logout","2022-12-19","07:07:33");
INSERT INTO `user_log` VALUES("36","4","admin_toda","Login","2022-12-19","07:07:39");
INSERT INTO `user_log` VALUES("37","4","admin_toda","Logout","2022-12-19","07:17:40");
INSERT INTO `user_log` VALUES("38","2","admin","Login","2022-12-19","07:17:44");
INSERT INTO `user_log` VALUES("39","2","admin","Logout","2022-12-19","07:25:18");
INSERT INTO `user_log` VALUES("40","4","admin_toda","Login","2022-12-19","07:25:23");
INSERT INTO `user_log` VALUES("41","4","admin_toda","Logout","2022-12-19","07:29:03");
INSERT INTO `user_log` VALUES("42","4","satoda","Login","2022-12-19","07:29:14");
INSERT INTO `user_log` VALUES("43","4","satoda","Logout","2022-12-19","07:31:35");
INSERT INTO `user_log` VALUES("44","2","admin","Login","2022-12-19","07:31:40");
INSERT INTO `user_log` VALUES("45","2","admin","Logout","2022-12-19","07:32:24");
INSERT INTO `user_log` VALUES("46","2","admin","Login","2022-12-19","07:32:28");
INSERT INTO `user_log` VALUES("47","2","admin","Logout","2022-12-19","07:32:42");
INSERT INTO `user_log` VALUES("48","4","satoda","Login","2022-12-19","07:32:47");
INSERT INTO `user_log` VALUES("49","4","satoda","Logout","2022-12-19","07:35:17");
INSERT INTO `user_log` VALUES("50","4","satoda","Login","2022-12-19","07:35:23");
INSERT INTO `user_log` VALUES("51","4","satoda","Logout","2022-12-19","07:37:07");
INSERT INTO `user_log` VALUES("52","11","satoda","Register","2022-12-19","07:47:29");
INSERT INTO `user_log` VALUES("53","11","satoda","Login","2022-12-19","07:56:31");
INSERT INTO `user_log` VALUES("54","11","satoda","Login","2022-12-19","07:57:11");
INSERT INTO `user_log` VALUES("55","11","satoda","Logout","2022-12-19","08:30:45");
INSERT INTO `user_log` VALUES("56","2","admin","Login","2022-12-19","08:31:03");
INSERT INTO `user_log` VALUES("57","2","admin","Logout","2022-12-19","08:34:25");
INSERT INTO `user_log` VALUES("58","11","satoda","Login","2022-12-19","08:34:40");
INSERT INTO `user_log` VALUES("59","11","satoda","Logout","2022-12-19","08:37:52");
INSERT INTO `user_log` VALUES("60","2","admin","Login","2022-12-19","08:38:42");
INSERT INTO `user_log` VALUES("61","2","admin","Logout","2022-12-19","09:23:25");
INSERT INTO `user_log` VALUES("62","2","admin","Login","2022-12-19","09:36:41");
INSERT INTO `user_log` VALUES("63","17","mj1122","Registered Mark Jayson One Algarne to driver list","2022-12-19","09:44:10");
INSERT INTO `user_log` VALUES("64","2","admin","Logout","2022-12-19","09:44:45");
INSERT INTO `user_log` VALUES("65","8","client1","Login","2022-12-19","11:31:15");
INSERT INTO `user_log` VALUES("66","2","admin","Login","2022-12-20","11:22:10");
INSERT INTO `user_log` VALUES("67","2","admin","Logout","2022-12-20","11:23:12");
INSERT INTO `user_log` VALUES("68","8","client1","Login","2022-12-20","11:23:26");
INSERT INTO `user_log` VALUES("69","8","client1","Login","2022-12-20","11:29:29");
INSERT INTO `user_log` VALUES("70","8","client1","Login","2022-12-20","11:32:07");
INSERT INTO `user_log` VALUES("71","8","client1","Login","2022-12-20","12:27:09");
INSERT INTO `user_log` VALUES("72","8","client1","Login","2022-12-20","02:22:45");
INSERT INTO `user_log` VALUES("73","8","client1","Login","2022-12-20","02:40:42");
INSERT INTO `user_log` VALUES("74","8","client1","Login","2022-12-20","04:05:14");
INSERT INTO `user_log` VALUES("75","8","client1","Logout","2022-12-20","04:06:07");
INSERT INTO `user_log` VALUES("76","8","client1","Login","2022-12-20","04:06:35");
INSERT INTO `user_log` VALUES("77","8","client1","Login","2022-12-20","04:07:27");
INSERT INTO `user_log` VALUES("78","8","client1","Logout","2022-12-20","04:38:35");
INSERT INTO `user_log` VALUES("79","2","admin","Login","2022-12-20","04:38:45");
INSERT INTO `user_log` VALUES("80","2","admin","Logout","2022-12-20","04:50:19");
INSERT INTO `user_log` VALUES("81","11","satoda","Login","2022-12-20","04:50:23");
INSERT INTO `user_log` VALUES("82","11","satoda","Logout","2022-12-20","04:50:32");
INSERT INTO `user_log` VALUES("83","8","client1","Login","2022-12-20","04:50:38");
INSERT INTO `user_log` VALUES("84","2","admin","Login","2022-12-21","05:23:28");
INSERT INTO `user_log` VALUES("85","2","admin","Backup the database named backup-database_trider-20221221_173127.sql.gz","2022-12-21","05:31:27");
INSERT INTO `user_log` VALUES("86","2","admin","Backup the database named backup-database_trider-20221221_173315.sql.gz","2022-12-21","05:33:15");
