CREATE DATABASE IF NOT EXISTS `database_trider`;

USE database_trider;

DROP TABLE IF EXISTS `admin_toda`;

CREATE TABLE `admin_toda` (
  `admin_id` int(11) NOT NULL,
  `toda` tinytext NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `admin_toda` VALUES("24","SATODA");



DROP TABLE IF EXISTS `bookings`;

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_name` varchar(255) NOT NULL,
  `origin_latitude` varchar(255) NOT NULL,
  `origin_longitude` varchar(255) NOT NULL,
  `destination_latitude` varchar(255) NOT NULL,
  `destination_longitude` varchar(255) NOT NULL,
  `client_phone` tinytext NOT NULL,
  `driver_name` varchar(255) DEFAULT NULL,
  `driver_phone` tinytext DEFAULT NULL,
  `fare` int(32) NOT NULL,
  `toda` tinytext DEFAULT NULL,
  `plate_number` varchar(255) DEFAULT NULL,
  `date_booked` date NOT NULL DEFAULT current_timestamp(),
  `mtop` varchar(255) DEFAULT NULL,
  `booking_status` tinytext NOT NULL,
  `destination_details` varchar(255) NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `bookings` VALUES("12","Client One Juan","15.7436811","121.5773917","15.7506079","121.5689202","09125321455","Mark Jayson One Algarne","09125345551","58","satoda","5656464","2022-12-22","3005","success","Zabali Hanging Bridge");
INSERT INTO `bookings` VALUES("13","Client One Juan","15.7436811","121.5773917","14.5353011","120.9831995","09125321455","Mark Jayson Two Algarne","09125345551","2622","satoda","5656464","2022-12-22","3005","success","SM Mall of Asia");
INSERT INTO `bookings` VALUES("14","Client One Juan","15.7436811","121.5773917","14.0316181","121.4318505","09125321455","Mark Jayson One Algarne","09125345551","3460","satoda","5656464","2022-12-22","3005","pending","Santa Lucia Falls");
INSERT INTO `bookings` VALUES("15","Client One Juan","15.7436811","121.5773917","15.755179","121.5730095","09125321455","Mark Jayson One Algarne","09125345551","65","satoda","5656464","2022-12-22","3005","pending","Beachfront of Baler");
INSERT INTO `bookings` VALUES("16","Client One Juan","15.7436811","121.5773917","15.7506079","121.5689202","09125321455","Mark Jayson One Algarne","09125345551","58","satoda","5656464","2022-12-22","3005","pending","Zabali Hanging Bridge");



DROP TABLE IF EXISTS `client_list`;

CREATE TABLE `client_list` (
  `user_id` int(11) NOT NULL,
  `client_firstname` varchar(255) NOT NULL,
  `client_middlename` varchar(255) NOT NULL,
  `client_lastname` varchar(255) NOT NULL,
  `client_suffix` varchar(11) NOT NULL,
  `gender` tinytext NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `client_list` VALUES("4","Asdasd","Asdas","Asda","jrszk","Male");
INSERT INTO `client_list` VALUES("8","Client","One","Juan","jr","Male");



DROP TABLE IF EXISTS `driver_list`;

CREATE TABLE `driver_list` (
  `user_id` int(255) NOT NULL,
  `driver_firstname` varchar(255) NOT NULL,
  `driver_middlename` varchar(255) NOT NULL,
  `driver_lastname` varchar(255) NOT NULL,
  `driver_sufix` varchar(11) NOT NULL,
  `gender` tinytext NOT NULL,
  `plate_number` varchar(255) NOT NULL,
  `license` varchar(255) NOT NULL,
  `toda` tinytext NOT NULL,
  `mtop` tinytext NOT NULL,
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `driver_list` VALUES("11","admin","Qwerty","Algarne","jr","Male","89564651312","89465435","KIPTODA","3001");
INSERT INTO `driver_list` VALUES("17","Mark Jayson","One","Algarne","jr","Male","5656464","549561","KIPTODA","3005");
INSERT INTO `driver_list` VALUES("18","Dsada","Asdas","Asdas","a","Male","8745129630","464521744","SATODA","8523");



DROP TABLE IF EXISTS `queuing`;

CREATE TABLE `queuing` (
  `que_id` int(255) NOT NULL AUTO_INCREMENT,
  `driver_name` varchar(255) NOT NULL,
  `date_que` date NOT NULL DEFAULT current_timestamp(),
  `time_que` time NOT NULL DEFAULT current_timestamp(),
  `driver_id` int(255) NOT NULL,
  `que_status` tinytext NOT NULL,
  PRIMARY KEY (`que_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `queuing` VALUES("1","Mark Jayson One Algarne","2022-12-22","07:39:29","17","Done");
INSERT INTO `queuing` VALUES("2","Mark Jayson One Algarne","2022-12-22","07:40:30","17","Done");
INSERT INTO `queuing` VALUES("3","Mark Jayson One Algarne","2022-12-22","07:40:50","17","Done");
INSERT INTO `queuing` VALUES("4","Mark Jayson One Algarne","2022-12-22","08:00:57","17","Done");
INSERT INTO `queuing` VALUES("5","Mark Jayson One Algarne","2022-12-22","08:50:39","17","Done");
INSERT INTO `queuing` VALUES("6","Mark Jayson One Algarne","2022-12-22","08:51:06","17","Done");
INSERT INTO `queuing` VALUES("7","Mark Jayson One Algarne","2022-12-22","08:51:21","17","Done");
INSERT INTO `queuing` VALUES("8","Mark Jayson One Algarne","2022-12-22","10:03:17","17","Done");
INSERT INTO `queuing` VALUES("9","Mark Jayson One Algarne","2022-12-22","10:03:19","17","Done");
INSERT INTO `queuing` VALUES("10","Mark Jayson One Algarne","2022-12-22","10:03:21","17","Done");



DROP TABLE IF EXISTS `user_list`;

CREATE TABLE `user_list` (
  `user_id` int(255) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone_number` varchar(16) NOT NULL,
  `email` varchar(255) NOT NULL,
  `position` tinytext NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_list` VALUES("2","admin","$2y$10$r4O/4/VnlqIdJ8l6v80FE.nNu0Un8xf39dR/sXfSk9FGFkWnz8tZq","09123456789","admin@example.com","Administrator");
INSERT INTO `user_list` VALUES("8","client1","$2y$10$Ss6UsDvdPg/aQEBz2zXAa.XvgA3.e5t21MfLLyVwqUn8QDZ2Zgs6m","09125321455","client1@example.com","User");
INSERT INTO `user_list` VALUES("11","kiptoda","$2y$10$kJNjKClcoNHURBARdMxaRefs0H0ZG/oKdQedmLZ8xkQBkFEJeDzg6","09998989898","MarkJayson@example.com","TODA-Admin");
INSERT INTO `user_list` VALUES("17","mj1122","$2y$10$Sx0Wi5Ak0D/uKSgaqref6ehxuY.4El4KJzPzQkNhAsyxZDhlMS4hu","09125345551","MarkJayson848484@example.com","Driver");
INSERT INTO `user_list` VALUES("18","driver2","$2y$10$.qdD7BAnqjm0zOwK5KQKsumSVzOnzBWTUlbh77LQHQnBi5ULfUi6C","0990987643","asdfg@gmail.com","Driver");
INSERT INTO `user_list` VALUES("24","SATODA","$2y$10$TwPemNC5gsEZNrY9FhOfv..GbtlMnsQ8DWOJSagrstCc/UFRi50Oi","8952484515","asdfgadasdasdas@gmail.com","TODA-Admin");



DROP TABLE IF EXISTS `user_log`;

CREATE TABLE `user_log` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` tinytext NOT NULL,
  `action` varchar(255) NOT NULL,
  `logDate` date NOT NULL,
  `logTime` time NOT NULL,
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `user_log` VALUES("1","4","dasdas","Register","2022-12-15","12:07:14");
INSERT INTO `user_log` VALUES("2","2","admin","Login","2022-12-15","12:22:53");
INSERT INTO `user_log` VALUES("3","2","admin","Login","2022-12-15","12:23:02");
INSERT INTO `user_log` VALUES("4","2","admin","Logout","2022-12-15","12:26:16");
INSERT INTO `user_log` VALUES("5","2","admin","Login","2022-12-15","12:26:19");
INSERT INTO `user_log` VALUES("6","2","admin","Logout","2022-12-15","12:27:24");
INSERT INTO `user_log` VALUES("7","2","admin","Login","2022-12-15","12:27:27");
INSERT INTO `user_log` VALUES("8","2","admin","Logout","2022-12-15","12:30:41");
INSERT INTO `user_log` VALUES("9","2","admin","Login","2022-12-15","12:30:43");
INSERT INTO `user_log` VALUES("10","2","admin","Logout","2022-12-15","12:31:24");
INSERT INTO `user_log` VALUES("11","2","admin","Login","2022-12-15","12:31:26");
INSERT INTO `user_log` VALUES("12","2","admin","Logout","2022-12-15","12:37:46");
INSERT INTO `user_log` VALUES("13","2","admin","Login","2022-12-15","12:37:48");
INSERT INTO `user_log` VALUES("14","2","admin","Logout","2022-12-15","12:38:40");
INSERT INTO `user_log` VALUES("15","2","admin","Login","2022-12-15","12:39:54");
INSERT INTO `user_log` VALUES("16","2","admin","Login","2022-12-15","12:42:07");
INSERT INTO `user_log` VALUES("17","2","admin","Logout","2022-12-15","01:44:41");
INSERT INTO `user_log` VALUES("18","2","admin","Login","2022-12-15","01:45:02");
INSERT INTO `user_log` VALUES("19","5","dsaaa","Register","2022-12-15","03:49:55");
INSERT INTO `user_log` VALUES("20","6","dsaaaasd","Registered Asdas Asdas Asd to client list","2022-12-15","04:02:09");
INSERT INTO `user_log` VALUES("21","7","asd","Registered Asd Asdas Asdasd to client list","2022-12-15","04:05:30");
INSERT INTO `user_log` VALUES("22","2","admin","Login","2022-12-19","04:53:14");
INSERT INTO `user_log` VALUES("23","2","admin","Login","2022-12-19","05:36:52");
INSERT INTO `user_log` VALUES("24","2","admin","Logout","2022-12-19","05:36:57");
INSERT INTO `user_log` VALUES("25","2","admin","Login","2022-12-19","05:37:01");
INSERT INTO `user_log` VALUES("26","2","admin","Logout","2022-12-19","05:51:40");
INSERT INTO `user_log` VALUES("27","2","admin","Login","2022-12-19","05:51:43");
INSERT INTO `user_log` VALUES("28","2","admin","Logout","2022-12-19","06:01:58");
INSERT INTO `user_log` VALUES("29","8","client1","Register","2022-12-19","06:04:53");
INSERT INTO `user_log` VALUES("30","8","client1","Login","2022-12-19","06:05:03");
INSERT INTO `user_log` VALUES("31","8","client1","Login","2022-12-19","06:07:48");
INSERT INTO `user_log` VALUES("32","8","client1","Login","2022-12-19","06:08:23");
INSERT INTO `user_log` VALUES("33","8","client1","Logout","2022-12-19","06:14:09");
INSERT INTO `user_log` VALUES("34","2","admin","Login","2022-12-19","06:14:15");
INSERT INTO `user_log` VALUES("35","2","admin","Logout","2022-12-19","07:07:33");
INSERT INTO `user_log` VALUES("36","4","admin_toda","Login","2022-12-19","07:07:39");
INSERT INTO `user_log` VALUES("37","4","admin_toda","Logout","2022-12-19","07:17:40");
INSERT INTO `user_log` VALUES("38","2","admin","Login","2022-12-19","07:17:44");
INSERT INTO `user_log` VALUES("39","2","admin","Logout","2022-12-19","07:25:18");
INSERT INTO `user_log` VALUES("40","4","admin_toda","Login","2022-12-19","07:25:23");
INSERT INTO `user_log` VALUES("41","4","admin_toda","Logout","2022-12-19","07:29:03");
INSERT INTO `user_log` VALUES("42","4","satoda","Login","2022-12-19","07:29:14");
INSERT INTO `user_log` VALUES("43","4","satoda","Logout","2022-12-19","07:31:35");
INSERT INTO `user_log` VALUES("44","2","admin","Login","2022-12-19","07:31:40");
INSERT INTO `user_log` VALUES("45","2","admin","Logout","2022-12-19","07:32:24");
INSERT INTO `user_log` VALUES("46","2","admin","Login","2022-12-19","07:32:28");
INSERT INTO `user_log` VALUES("47","2","admin","Logout","2022-12-19","07:32:42");
INSERT INTO `user_log` VALUES("48","4","satoda","Login","2022-12-19","07:32:47");
INSERT INTO `user_log` VALUES("49","4","satoda","Logout","2022-12-19","07:35:17");
INSERT INTO `user_log` VALUES("50","4","satoda","Login","2022-12-19","07:35:23");
INSERT INTO `user_log` VALUES("51","4","satoda","Logout","2022-12-19","07:37:07");
INSERT INTO `user_log` VALUES("52","11","satoda","Register","2022-12-19","07:47:29");
INSERT INTO `user_log` VALUES("53","11","satoda","Login","2022-12-19","07:56:31");
INSERT INTO `user_log` VALUES("54","11","satoda","Login","2022-12-19","07:57:11");
INSERT INTO `user_log` VALUES("55","11","satoda","Logout","2022-12-19","08:30:45");
INSERT INTO `user_log` VALUES("56","2","admin","Login","2022-12-19","08:31:03");
INSERT INTO `user_log` VALUES("57","2","admin","Logout","2022-12-19","08:34:25");
INSERT INTO `user_log` VALUES("58","11","satoda","Login","2022-12-19","08:34:40");
INSERT INTO `user_log` VALUES("59","11","satoda","Logout","2022-12-19","08:37:52");
INSERT INTO `user_log` VALUES("60","2","admin","Login","2022-12-19","08:38:42");
INSERT INTO `user_log` VALUES("61","2","admin","Logout","2022-12-19","09:23:25");
INSERT INTO `user_log` VALUES("62","2","admin","Login","2022-12-19","09:36:41");
INSERT INTO `user_log` VALUES("63","17","mj1122","Registered Mark Jayson One Algarne to driver list","2022-12-19","09:44:10");
INSERT INTO `user_log` VALUES("64","2","admin","Logout","2022-12-19","09:44:45");
INSERT INTO `user_log` VALUES("65","8","client1","Login","2022-12-19","11:31:15");
INSERT INTO `user_log` VALUES("66","2","admin","Login","2022-12-20","11:22:10");
INSERT INTO `user_log` VALUES("67","2","admin","Logout","2022-12-20","11:23:12");
INSERT INTO `user_log` VALUES("68","8","client1","Login","2022-12-20","11:23:26");
INSERT INTO `user_log` VALUES("69","8","client1","Login","2022-12-20","11:29:29");
INSERT INTO `user_log` VALUES("70","8","client1","Login","2022-12-20","11:32:07");
INSERT INTO `user_log` VALUES("71","8","client1","Login","2022-12-20","12:27:09");
INSERT INTO `user_log` VALUES("72","8","client1","Login","2022-12-20","02:22:45");
INSERT INTO `user_log` VALUES("73","8","client1","Login","2022-12-20","02:40:42");
INSERT INTO `user_log` VALUES("74","8","client1","Login","2022-12-20","04:05:14");
INSERT INTO `user_log` VALUES("75","8","client1","Logout","2022-12-20","04:06:07");
INSERT INTO `user_log` VALUES("76","8","client1","Login","2022-12-20","04:06:35");
INSERT INTO `user_log` VALUES("77","8","client1","Login","2022-12-20","04:07:27");
INSERT INTO `user_log` VALUES("78","8","client1","Logout","2022-12-20","04:38:35");
INSERT INTO `user_log` VALUES("79","2","admin","Login","2022-12-20","04:38:45");
INSERT INTO `user_log` VALUES("80","2","admin","Logout","2022-12-20","04:50:19");
INSERT INTO `user_log` VALUES("81","11","satoda","Login","2022-12-20","04:50:23");
INSERT INTO `user_log` VALUES("82","11","satoda","Logout","2022-12-20","04:50:32");
INSERT INTO `user_log` VALUES("83","8","client1","Login","2022-12-20","04:50:38");
INSERT INTO `user_log` VALUES("84","2","admin","Login","2022-12-21","05:23:28");
INSERT INTO `user_log` VALUES("85","2","admin","Backup the database named backup-database_trider-20221221_173127.sql.gz","2022-12-21","05:31:27");
INSERT INTO `user_log` VALUES("86","2","admin","Backup the database named backup-database_trider-20221221_173315.sql.gz","2022-12-21","05:33:15");
INSERT INTO `user_log` VALUES("87","2","admin","Restore the database using backup-database_trider-20221221_173401.sql.gz","2022-12-21","05:42:42");
INSERT INTO `user_log` VALUES("88","2","admin","Backup the database named backup-database_trider-20221221_174804.sql.gz","2022-12-21","05:48:04");
INSERT INTO `user_log` VALUES("89","2","admin","Backup the database named backup-database_trider-20221221_174807.sql.gz","2022-12-21","05:48:07");
INSERT INTO `user_log` VALUES("90","2","admin","Backup the database named backup-database_trider-20221221_174821.sql.gz","2022-12-21","05:48:21");
INSERT INTO `user_log` VALUES("91","2","admin","Backup the database named backup-database_trider-20221221_174835.sql.gz","2022-12-21","05:48:35");
INSERT INTO `user_log` VALUES("92","2","admin","Logout","2022-12-21","06:02:55");
INSERT INTO `user_log` VALUES("93","8","client1","Login","2022-12-21","06:02:59");
INSERT INTO `user_log` VALUES("94","8","client1","Logout","2022-12-21","06:13:11");
INSERT INTO `user_log` VALUES("95","2","admin","Login","2022-12-21","06:13:16");
INSERT INTO `user_log` VALUES("96","2","admin","Logout","2022-12-21","06:14:08");
INSERT INTO `user_log` VALUES("97","17","mj1122","Login","2022-12-21","06:15:03");
INSERT INTO `user_log` VALUES("98","17","mj1122","Login","2022-12-21","06:15:04");
INSERT INTO `user_log` VALUES("99","17","mj1122","Login","2022-12-21","06:15:04");
INSERT INTO `user_log` VALUES("100","17","mj1122","Login","2022-12-21","06:15:04");
INSERT INTO `user_log` VALUES("101","17","mj1122","Logout","2022-12-21","06:15:13");
INSERT INTO `user_log` VALUES("102","11","satoda","Login","2022-12-21","06:15:21");
INSERT INTO `user_log` VALUES("103","11","satoda","Logout","2022-12-21","06:58:05");
INSERT INTO `user_log` VALUES("104","8","client1","Login","2022-12-21","06:58:11");
INSERT INTO `user_log` VALUES("105","8","client1","Login","2022-12-21","10:24:08");
INSERT INTO `user_log` VALUES("106","8","client1","Logout","2022-12-22","01:40:12");
INSERT INTO `user_log` VALUES("107","2","admin","Login","2022-12-22","01:40:16");
INSERT INTO `user_log` VALUES("108","2","admin","Logout","2022-12-22","01:41:02");
INSERT INTO `user_log` VALUES("109","8","client1","Login","2022-12-22","01:41:06");
INSERT INTO `user_log` VALUES("110","8","client1","Login","2022-12-22","01:55:12");
INSERT INTO `user_log` VALUES("111","8","client1","Login","2022-12-22","03:59:18");
INSERT INTO `user_log` VALUES("112","8","client1","Logout","2022-12-22","04:33:43");
INSERT INTO `user_log` VALUES("113","8","client1","Login","2022-12-22","04:33:49");
INSERT INTO `user_log` VALUES("114","8","client1","Logout","2022-12-22","06:20:51");
INSERT INTO `user_log` VALUES("115","8","client1","Login","2022-12-22","06:20:59");
INSERT INTO `user_log` VALUES("116","8","client1","Logout","2022-12-22","06:26:46");
INSERT INTO `user_log` VALUES("117","8","client1","Login","2022-12-22","06:27:20");
INSERT INTO `user_log` VALUES("118","8","client1","Logout","2022-12-22","06:35:23");
INSERT INTO `user_log` VALUES("119","8","client1","Login","2022-12-22","06:35:29");
INSERT INTO `user_log` VALUES("120","8","client1","Logout","2022-12-22","06:49:24");
INSERT INTO `user_log` VALUES("121","11","satoda","Login","2022-12-22","06:49:45");
INSERT INTO `user_log` VALUES("122","11","satoda","Logout","2022-12-22","06:52:15");
INSERT INTO `user_log` VALUES("123","11","satoda","Login","2022-12-22","06:52:20");
INSERT INTO `user_log` VALUES("124","11","satoda","Logout","2022-12-22","06:52:53");
INSERT INTO `user_log` VALUES("125","11","satoda","Login","2022-12-22","06:52:59");
INSERT INTO `user_log` VALUES("126","11","satoda","Logout","2022-12-22","08:01:26");
INSERT INTO `user_log` VALUES("127","8","client1","Login","2022-12-22","08:01:32");
INSERT INTO `user_log` VALUES("128","11","satoda","Login","2022-12-22","08:49:04");
INSERT INTO `user_log` VALUES("129","11","satoda","Logout","2022-12-22","08:54:48");
INSERT INTO `user_log` VALUES("130","8","client1","Logout","2022-12-22","09:41:30");
INSERT INTO `user_log` VALUES("131","17","mj1122","Login","2022-12-22","09:41:39");
INSERT INTO `user_log` VALUES("132","17","mj1122","Logout","2022-12-22","09:59:10");
INSERT INTO `user_log` VALUES("133","8","client1","Login","2022-12-22","09:59:14");
INSERT INTO `user_log` VALUES("134","11","satoda","Login","2022-12-22","10:03:06");
INSERT INTO `user_log` VALUES("135","8","client1","Logout","2022-12-22","10:05:23");
INSERT INTO `user_log` VALUES("136","17","mj1122","Login","2022-12-22","10:05:29");
INSERT INTO `user_log` VALUES("137","17","mj1122","Logout","2022-12-22","11:10:17");
INSERT INTO `user_log` VALUES("138","8","client1","Login","2022-12-22","11:10:23");
INSERT INTO `user_log` VALUES("139","8","client1","Logout","2022-12-22","11:11:12");
INSERT INTO `user_log` VALUES("140","2","admin","Login","2022-12-22","11:11:21");
INSERT INTO `user_log` VALUES("141","18","driver2","Registered Dsada Asdas Asdas to driver list","2022-12-22","11:13:34");
INSERT INTO `user_log` VALUES("142","2","admin","Logout","2022-12-22","11:14:12");
INSERT INTO `user_log` VALUES("143","2","admin","Login","2022-12-22","11:14:17");
INSERT INTO `user_log` VALUES("144","2","admin","Logout","2022-12-22","11:15:12");
INSERT INTO `user_log` VALUES("145","8","client1","Login","2022-12-22","11:15:16");
INSERT INTO `user_log` VALUES("146","8","client1","Logout","2022-12-22","11:16:48");
INSERT INTO `user_log` VALUES("147","2","admin","Login","2022-12-22","11:17:28");
INSERT INTO `user_log` VALUES("148","2","admin","Restore the database using backup-database_trider-20221222_112215.sql.gz","2022-12-22","11:59:10");
INSERT INTO `user_log` VALUES("149","2","admin","Logout","2022-12-22","12:04:18");
INSERT INTO `user_log` VALUES("150","8","client1","Login","2022-12-22","12:04:24");
INSERT INTO `user_log` VALUES("151","8","client1","Logout","2022-12-22","12:05:37");
INSERT INTO `user_log` VALUES("152","2","admin","Login","2022-12-22","12:05:41");
INSERT INTO `user_log` VALUES("153","8","client1","Login","2022-12-22","12:06:06");
INSERT INTO `user_log` VALUES("154","8","client1","Logout","2022-12-22","12:07:50");
INSERT INTO `user_log` VALUES("155","2","admin","Login","2022-12-22","12:08:12");
INSERT INTO `user_log` VALUES("156","2","admin","Logout","2022-12-22","12:11:26");
INSERT INTO `user_log` VALUES("157","17","mj1122","Login","2022-12-22","12:11:41");
INSERT INTO `user_log` VALUES("158","17","mj1122","Logout","2022-12-22","12:13:00");
INSERT INTO `user_log` VALUES("159","8","client1","Login","2022-12-22","12:13:23");
INSERT INTO `user_log` VALUES("160","8","client1","Logout","2022-12-22","12:14:21");
